=======
Credits
=======

Development Lead
----------------

* Simon Birrer <sibirrer@gmail.com>

Contributors (alphabetic)
-------------------------

* Joel Akeret
* Adam Amara
* Xuheng Ding
* Kevin Fusshoeller
* Aymeric Galan
* Daniel Gilman
* Felix A. Kuhn
* Felix Mayor
* Martin Millon
* Anna Nierenberg
* Brian Nord
* Ji Won Park
* Thomas Schmidt
* Anowar Shajib
* Lyne Van de Vyvere
* Cyril Welschen
* Lilan Yang
