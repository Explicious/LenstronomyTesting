__author__ = 'Simon Birrer'
__email__ = 'sibirrer@gmail.com'
__version__ = '0.1.0'
