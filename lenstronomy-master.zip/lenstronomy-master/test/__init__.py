import os


IMAGE_DATA_PATH = os.path.join(os.path.dirname(__file__), 'Test_data','RXJ1131_1231_test.fits')
